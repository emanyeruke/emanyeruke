package springcommonsmodule.exception;

public class IllegalAccessException extends RuntimeException {
    public IllegalAccessException(String s) {
        super(s);
    }
}
