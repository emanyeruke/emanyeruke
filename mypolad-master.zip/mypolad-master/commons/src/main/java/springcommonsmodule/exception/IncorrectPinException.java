package springcommonsmodule.exception;

public class IncorrectPinException extends RuntimeException {

    public IncorrectPinException(final String s) {
        super(s);
    }
}
