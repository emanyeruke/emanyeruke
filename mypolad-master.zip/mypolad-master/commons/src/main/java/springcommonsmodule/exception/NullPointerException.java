package springcommonsmodule.exception;

public class NullPointerException extends RuntimeException {

    public NullPointerException(final String s) {
        super(s);
    }
}
