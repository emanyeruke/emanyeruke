package springcommonsmodule.exception;

public class VelocityException extends RuntimeException {

    public VelocityException(final String s) {
        super(s);
    }
}
