package springcommonsmodule.exception;

public class MobileNumberInvalidException extends RuntimeException {

    public MobileNumberInvalidException(final String s) {
        super(s);
    }
}

