package zw.co.mynhaka.polad.domain.dtos.policyholder;

import lombok.Data;

@Data
public class SearchPolicyholderDto {

    private String firstname;
    private String lastname;
    private String email;
}
