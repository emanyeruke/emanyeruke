package zw.co.mynhaka.polad.domain.enums;

public enum Position {
    AGENT_EXECUTIVE,
    AGENT,
    TEAM_LEADER,
    REGIONAL_MANAGER
}
