package zw.co.mynhaka.polad.domain.enums;

public enum WithdrawalStatus {
    NEW,
    APPROVED,
    PAID
}
