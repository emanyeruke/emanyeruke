package zw.co.mynhaka.polad.domain.enums;

public enum BaseCurrency {
    ZWL,
    USD,
    NOSTRO
}
