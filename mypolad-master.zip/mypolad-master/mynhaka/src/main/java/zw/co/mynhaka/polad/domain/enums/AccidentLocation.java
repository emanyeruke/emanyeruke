package zw.co.mynhaka.polad.domain.enums;

public enum AccidentLocation {
    ON_JOB,
    OFF_JOB
}
