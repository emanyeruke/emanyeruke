package zw.co.mynhaka.polad.domain.enums;

public enum DeathCause {
    ACCIDENT,
    SICKNESS,
    OTHER
}
