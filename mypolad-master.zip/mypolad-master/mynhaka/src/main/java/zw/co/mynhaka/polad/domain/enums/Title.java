package zw.co.mynhaka.polad.domain.enums;

public enum Title {
    MR,
    MRS,
    DR,
    MISS,
    MS,
    PROF,
    ENG
}
