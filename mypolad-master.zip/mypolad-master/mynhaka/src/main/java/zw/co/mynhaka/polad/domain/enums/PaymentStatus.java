package zw.co.mynhaka.polad.domain.enums;

public enum PaymentStatus {
    INITIATED,
    CANCELLED,
    REVERSED,
    VALIDATED
}
