package zw.co.mynhaka.polad.domain.dtos.claim;

import lombok.Data;

@Data
public class RefundPolicyCreateDto {

    private String policyNumber;

//    private PolicyType policyType;
//
//    private String lifeAssuredName;
//
//    @IdNumberConstraint
//    private String idNumber;
//
//    @ContactNumberConstraint
//    private String contactNumber;
//
//    @Email
//    private String email;
//
//    @FutureOrPresent
//    private LocalDate effectiveDate;
//
//    private String reason;
//
//    private String moreInfomation;

}
