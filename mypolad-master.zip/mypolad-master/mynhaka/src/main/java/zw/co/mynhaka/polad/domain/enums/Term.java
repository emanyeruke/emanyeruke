package zw.co.mynhaka.polad.domain.enums;

public enum Term {
    TEN_YEAR,
    FIFTEEN_YEAR,
    TWENTY_YEAR,
    OPEN
}
