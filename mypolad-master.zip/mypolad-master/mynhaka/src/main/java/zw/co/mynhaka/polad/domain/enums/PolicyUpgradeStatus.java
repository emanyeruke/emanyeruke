package zw.co.mynhaka.polad.domain.enums;

public enum PolicyUpgradeStatus {
    INITIAL,
    UPGRADED,
    DOWNGRADED

}
