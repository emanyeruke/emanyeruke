package zw.co.mynhaka.polad.domain.enums;

public enum Reason {
    FINANCIAL_CONSTRAINTS,
    PRODUCY_DOES_NOT_MEET_EXPECTATIONS,
    COOLING_OFF_PERIOD,
    UNHAPPY_WITH_SERVICE
}
