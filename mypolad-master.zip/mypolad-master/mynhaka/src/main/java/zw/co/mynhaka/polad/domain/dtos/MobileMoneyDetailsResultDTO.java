package zw.co.mynhaka.polad.domain.dtos;

import lombok.Data;

@Data
public class MobileMoneyDetailsResultDTO {
    private String mobileNumber;

    private String mobileAccountName;
}
