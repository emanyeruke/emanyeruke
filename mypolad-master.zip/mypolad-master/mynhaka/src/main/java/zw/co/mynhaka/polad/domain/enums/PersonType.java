package zw.co.mynhaka.polad.domain.enums;

public enum PersonType {
    SPOUSE,
    CHILD,
    PARENT,
    EXTENDED_FAMILY,
    PRINCIPAL,
    BENEFICIARY
}
