package zw.co.mynhaka.polad.domain.enums;

public enum MaturityStatus {
    NEW,
    APPROVED,
    PAID
}
