package zw.co.mynhaka.polad.domain.enums;

public enum Category {
    INFLUENCER,
    GATE_KEEPER,
    DECISION_MAKER,
    HR_OFFICER,
    ACCOUNTING_OFFICER
}
