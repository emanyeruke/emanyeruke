package zw.co.mynhaka.polad.domain.enums;

public enum ClientType {
    SSB("SSB"),
    CORPORATE("CORPORATE");


    public final String label;

     ClientType(String label){
        this.label = label;
    }

    }

