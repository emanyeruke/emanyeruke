package zw.co.mynhaka.polad.domain.dtos.invoice;

public class InvoiceUpdateDTO {
}
