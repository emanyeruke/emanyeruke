package zw.co.mynhaka.polad.domain.enums;

public enum PaymentMethod {
    CASH,
    STOP_ORDER,
    DEBIT_ORDER
}
