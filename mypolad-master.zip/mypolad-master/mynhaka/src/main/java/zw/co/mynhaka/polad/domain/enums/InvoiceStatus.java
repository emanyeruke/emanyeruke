package zw.co.mynhaka.polad.domain.enums;

import lombok.Getter;

@Getter
public enum InvoiceStatus {
    PAID, NEW, PARTIALLY_PAID
}
