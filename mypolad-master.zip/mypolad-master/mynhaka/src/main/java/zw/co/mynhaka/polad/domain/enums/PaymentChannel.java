package zw.co.mynhaka.polad.domain.enums;

public enum PaymentChannel {
    CASH,
    ECOCASH,
    ONEMONEY,
    TELECASH,
    RTGS,
    ZIPIT
}
