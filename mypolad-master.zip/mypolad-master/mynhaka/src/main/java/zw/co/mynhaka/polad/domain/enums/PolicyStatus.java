package zw.co.mynhaka.polad.domain.enums;

public enum PolicyStatus {
    WAITING_FOR_FIRST_PAYMENT,
    PAID_UP,
    IN_SUSPENSE,
    IN_ARREARS,
    CLOSED,
    CANCELLED
}
