package zw.co.mynhaka.polad.domain.enums;

public enum PremiumPayer {
    MAIN_LIFE_ASSURED,
    PREMIUM_PAYER,
    MAIN_LIFE_ASSURED_AND_PREMIUM_PAYER
}
