package zw.co.mynhaka.polad.domain.dtos.policyholder;

import lombok.Data;

@Data
public class AddressResultDTO {


    private String street;

    private String suburb;

    private String city;

}
