package zw.co.mynhaka.polad.domain.enums;

public enum ClaimStatus {
    INITIATED,
    AWAITING_PAYMENT,
    AUTHORISED_FOR_PAYMENT,
    VALIDATED,
    PAID,
    REJECTED
}
