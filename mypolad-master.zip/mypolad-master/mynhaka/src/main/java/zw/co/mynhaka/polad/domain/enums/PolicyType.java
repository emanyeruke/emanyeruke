package zw.co.mynhaka.polad.domain.enums;

public enum PolicyType {
    COMPREHENSIVE,
    SAVINGS,
    FUNERAL,
    ACCIDENT
}
