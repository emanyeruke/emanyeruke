package zw.co.mynhaka.polad.domain.enums;

public enum PolicyHolderStatus {
    ACTIVE,
    INACTIVE,
	NTU, //Not Taken Up
	NewBusinessStatus //Not paid yet
}
