package zw.co.mynhaka.polad.domain.enums;

public enum PaymentFrequency {
    MONTHLY,
    QUARTERLY,
    HALF_YEARLY,
    ANNUALLY
}
