package zw.co.mynhaka.polad.domain.dtos.agent;

import lombok.Data;

@Data
public class ManagerAgentResultDTO {
    private Long id;

    private String name;

    private String surname;

    private String email;
}
