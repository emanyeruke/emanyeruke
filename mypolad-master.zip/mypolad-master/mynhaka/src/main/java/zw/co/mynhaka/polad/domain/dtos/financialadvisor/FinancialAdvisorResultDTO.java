package zw.co.mynhaka.polad.domain.dtos.financialadvisor;

import lombok.Data;

@Data
public class FinancialAdvisorResultDTO {

    private Long id;

    private String name;

    private String surname;

    private String email;

    private String contactNumber;

   // private  String reference;
}
