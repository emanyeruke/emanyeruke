package zw.co.invenico.filestorageservice.exception;

public class FileNotFoundException extends RuntimeException {
    public FileNotFoundException(String s) {
        super(s);
    }
}

